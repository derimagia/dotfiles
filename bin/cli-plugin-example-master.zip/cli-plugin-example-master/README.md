# Terminus Plugin Example

A simple plugin for Terminus-CLI to demonstrate how to add new commands.

Learn more about Terminus and Terminus Plugins at:
[https://github.com/pantheon-systems/cli/wiki/Plugins](https://github.com/pantheon-systems/cli/wiki/Plugins)
